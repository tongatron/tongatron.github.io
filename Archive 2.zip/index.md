 

## Pagina in decostruzione

Progetti presenti, passati e futuri

- [Tongatron.org](https://www.tongatron.org/)
- [Midjourney personal showcase](https://www.tongatron.org/ai-showcase)
- [Mattia Martinengio e gli Psiconauti](https://sites.google.com/view/mm-e-gli-psiconauti/home-page)
- [Birdwatching dalla finestra](https://sites.google.com/view/window-birdwatching-turin/home-page)
- [Sereno Giocattoli](https://www.serenogiocattoli.it/)
- [Robottino](https://github.com/tongatron/robottino)
- [Linkedin](https://www.linkedin.com/in/giovannibindi/)
- [Profilo Discogs](https://www.discogs.com/artist/4340085-Giovanni-Bindi)
- [GitBook](https://tongatron.gitbook.io/tongatron/)
- [MagazzinoSereno90](https://github.com/tongatron/MagazzinoSereno90)
- [github.com/tongatron](https://github.com/tongatron)
- [🔒 Pagina privata](test/gateway.html)







