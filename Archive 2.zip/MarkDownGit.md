# MarkDown & Git

Note process

Articoli

[https://dev.to/scottshipp/my-note-taking-process-49pa](https://dev.to/scottshipp/my-note-taking-process-49pa)

[https://blog.devgenius.io/keep-your-notes-in-git-the-easy-way-3df3fe1f5b01](https://blog.devgenius.io/keep-your-notes-in-git-the-easy-way-3df3fe1f5b01)

Strumenti

[https://gohugo.io/installation/](https://gohugo.io/installation/)

[https://www.pandoc.org/](https://www.pandoc.org/) 

[https://www.youtube.com/watch?v=Hgucu1ch3mo](https://www.youtube.com/watch?v=Hgucu1ch3mo)