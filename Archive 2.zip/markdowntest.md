# Titolo Principale

## Sottotitolo

### Titolo di terzo livello

Questo è un testo di esempio in **grassetto** e *corsivo*.

Ecco un elenco puntato:

- Punto 1
- Punto 2
  - Punto 2.1
  - Punto 2.2
- Punto 3

Ecco un elenco numerato:

1. Elemento 1
2. Elemento 2
   1. Elemento 2.1
   2. Elemento 2.2
3. Elemento 3

Ecco un link:

[Visita OpenAI](https://www.openai.com)

Ecco un'immagine:

![Logo di OpenAI](https://yourimagelink.com/logo-openai.png)

Ecco un blocco di codice:

```javascript
function helloWorld() {
    console.log("Ciao, mondo!");
}
